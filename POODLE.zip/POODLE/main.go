package main

import (
	"crypto/tls"
	"net/http"
	"os"

	"github.com/cloudflare/cfssl/log"
	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
)

// init function to initialize useful variables, executes only once
func init() {
	// read environment variables
	log.Info("Reading environment variables...")
	err := godotenv.Load()
	// when not able to load .env file, throw an FATAL error
	if err != nil {
		log.Fatal(err)
	}
}

func setupRouter() *gin.Engine {
	log.Info("initializing gin router...")

	// set Production mode
	gin.SetMode(gin.ReleaseMode)

	// initialize gin router with default setting
	router := gin.Default()

	// register error logger
	router.Use(gin.ErrorLogger())

	// // frontend static content path, e.g. css, js files
	// staticPath := os.Getenv("STATIC_RES_PATH")
	// // router.Static("/tcverification", staticPath+"/tcverification")
	// router.Static("/tubenxt", staticPath+"/tubenxt")
	// router.NoRoute(func(c *gin.Context) {
	// 	url := c.Request.URL
	// 	path := url.Path
	// 	if strings.HasPrefix(path, "/tubenxt") {
	// 		c.File(staticPath + "/tubenxt/index.html")
	// 		return
	// 	}

	// })

	// removing X-XSS and clickjacking
	router.Use(func(c *gin.Context) {
		c.Header("X-XSS-Protection", "1; mode=block")
		c.Header("X-Frame-Options", "DENY")
		c.Next()
	})
	// register all REST API endpoints

	router.POST("/onSignin", OnSignin)

	return router

}

// main function of the REST API server
func main() {

	// start the REST API server here
	router := setupRouter()

	go func() {

	}()

	port := os.Getenv("APP_PORT")

	if port == "" {
		port = "9000"
	}
	port = ":" + port
	log.Infof("starting server on port: %v", port)

	privateKey := os.Getenv("SSL_PRIVATE_KEY_FILE_PATH")
	publicKey := os.Getenv("SSL_PUBLIC_KEY_FILE_PATH")
	if privateKey == "" || publicKey == "" {
		log.Fatal("missing private key and public key")
	}
	server := &http.Server{
		Addr:    port,
		Handler: router,
		TLSConfig: &tls.Config{
			MinVersion:               tls.VersionTLS10,
			MaxVersion:               tls.VersionTLS13,
			PreferServerCipherSuites: true,
		},
	}
	server.ListenAndServeTLS(publicKey, privateKey)

	log.Infof("Server stopped on port: %v", port)

}

func OnSignin(c *gin.Context) {

	reqBody := &struct {
		UserID   string `json:"userID"`
		Password string `json:"password"`
	}{}

	if err := c.Bind(reqBody); err != nil {
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": false,
		"token":   "",
		"message": "userID & password doesn't match",
	})

}
